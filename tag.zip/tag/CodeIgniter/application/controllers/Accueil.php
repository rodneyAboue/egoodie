<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Accueil extends CI_Controller
 {   
    

	public function __construct()
  	{                
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('db_model');
		$this->load->helper('url_helper');
    }

	public function actualite()
	{
		$data['titre'] = 'Actualités :';
		$data['actualites'] = $this->db_model->get_all_actualite();
		$this->load->view('templates/haut');
		$this->load->view('actualite_tout_afficher',$data);
		$this->load->view('templates/bas');
	}

 }
?>
