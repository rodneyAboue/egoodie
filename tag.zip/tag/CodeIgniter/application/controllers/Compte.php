<?php
class Compte extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('db_model');
		$this->load->helper('url_helper');
	}

	public function lister()
	{
		$data['titre']='Comptes';
		$data['logins']=$this->db_model->get_all_compte();
		$statut= $this->db_model->get_statuts($_SESSION['username']);
		
	if (empty ($statut))
		{
			$this->load->view('templates/haut');
			$this->load->view('probleme_connexion');
			$this->load->view('templates/bas');
		}
		else
		{
			$this->load->view('templates/haut'."_".$statut->CPT_statut);
			$this->load->view('compte_liste',$data);
			$this->load->view('templates/bas');
		}
	}


    public function creer()
	{
		$statut= $this->db_model->get_statuts($_SESSION['username']);
		if (strcmp($statut->CPT_statut,"A") !=0 )
		{	
			$this->load->view('templates/haut');
			$this->load->view('probleme_connexion');
			$this->load->view('templates/bas');
		}
	
		$this->load->helper('form');
 		$this->load->library('form_validation');
		$this->form_validation->set_rules('nom', 'nom', 'required');
		$this->form_validation->set_rules('prenom', 'prenom', 'required');
		$this->form_validation->set_rules('email', 'email' );
 		$this->form_validation->set_rules('pseudo', 'pseudo', 'required');
 		$this->form_validation->set_rules('mdp1', 'mdp1', 'required');
		$this->form_validation->set_rules('mdp2', 'mdp2', 'required');
		$this->form_validation->set_rules('statut', 'statut', 'required');
		$this->form_validation->set_rules('ptr', 'ptr');


		if ($this->form_validation->run() == FALSE)
	 	{
	       	$this->load->view('templates/haut'."_".$statut->CPT_statut);
	       	$this->load->view('compte_creer');
	       	$this->load->view('templates/bas');
	 	}
		else
 		{
			$mdp1=$this->input->post('mdp1');
			$mdp2=$this->input->post('mdp2');
			if (strcmp($mdp1,$mdp2) != 0)
			{
				$this->load->view('templates/haut'."_".$statut->CPT_statut);
    	   		$this->load->view('compte_creer');
				echo "les 2 mots de passe saisis sont différents ! ";
    	   		$this->load->view('templates/bas');
			}
			else
			{	
    			$this->db_model->set_compte();
				$this->lister();
		 	}
		}
	}

	public function connection()
	{
		$this->load->helper('form');
	 	$this->load->library('form_validation');
		$this->form_validation->set_rules('pseudo', 'pseudo', 'required');
	 	$this->form_validation->set_rules('mdp', 'mdp', 'required');

		if ($this->form_validation->run() == FALSE)
	 	{
	       	$this->load->view('templates/haut');
	       	$this->load->view('compte_connection');
	       	$this->load->view('templates/bas');
	 	}
		else
	 	{
			$salt = "LeSelDUsCieclePourAllongerleMoT_TestPas1see781";
			$username=$this->input->post('pseudo');
			$mdp=$this->input->post('mdp');
			$password=hash('sha256', $salt.$mdp);

			if ($this->db_model->try_connect($username,$password))
	     	{
				$session_data = array('username'=>$username);
				$this->session->set_userdata($session_data);
				$statut= $this->db_model->get_statuts($username);
   		  		$this->load->view('templates/haut'."_".$statut->CPT_statut);
   	    		$this->load->view('compte_'.$statut->CPT_statut.'_connecte');
   	    		$this->load->view('templates/bas');
			}
			else
			{
    	   		$this->load->view('templates/haut');
        		$this->load->view('compte_connection',$data);
        		$this->load->view('templates/bas');
			}
		}
	}


	public function deconnection()
		{
			$this->session->set_userdata('username');
			$this->load->view('templates/haut');
			$this->load->view('compte_deconnecte');
			$this->load->view('templates/bas');
		}



	public function accueil()
		{
		if (!isset ( $_SESSION['username'] ))
			{
			$this->load->view('templates/haut');
			$this->load->view('probleme_connexion');
			$this->load->view('templates/bas');
			}
		else
			{
			$statut= $this->db_model->get_statut($_SESSION['username']);
			$this->load->view('templates/haut'."_".$statut->CPT_statut);
			$this->load->view('compte_'.$statut->CPT_statut.'_connecte');
			$this->load->view('templates/bas');

			}





		}



}

?>
