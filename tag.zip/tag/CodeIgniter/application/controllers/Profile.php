
<?php


class Profile extends CI_Controller {

	public function __construct()
	{
	parent::__construct();
	$this->load->model('db_model');
	$this->load->helper('url_helper');
	}


	public function modification()
	{

		$this->load->helper('form');
 		$this->load->library('form_validation');
		$this->form_validation->set_rules('nom', 'nom', 'required');
 		$this->form_validation->set_rules('prenom', 'prenom', 'required');
		$this->form_validation->set_rules('mail', 'mail', 'required');
 		$this->form_validation->set_rules('mdp1', 'mdp1', 'required');
 		$this->form_validation->set_rules('mdp2', 'mdp2', 'required');
		$data['titre']="Votre profil:";
		$data['info']=$this->db_model->get_profil($_SESSION['username']);
		$info=$this->db_model->get_profil($_SESSION['username']);
		$statut= $this->db_model->get_statuts($_SESSION['username']);


		if (!isset($_SESSION))
			{
			$this->load->view('templates/haut');
			$this->load->view('probleme_connexion');
			$this->load->view('templates/bas');
			}
		
			if ($this->form_validation->run() == FALSE)
 			{
        		$this->load->view('templates/haut'."_".$statut->CPT_statut);
        		$this->load->view('profile_modification',$data);
        		$this->load->view('templates/bas');
 			}
			else
			{
				$nom=$this->input->post('nom');
				$prenom=$this->input->post('prenom');
				$mail=$this->input->post('mail');
				$mdp1=$this->input->post('mdp1');
				$mdp2=$this->input->post('mdp2');
				if ( $nom != $info->PFL_nom || $prenom != $info->PFL_prenom || $mail != $info->PFL_mail)
				{ 
					$this->db->query("Update PROFIL set PFL_prenom = '".$prenom."', PFL_nom = '".$nom."', PFL_mail = '".$mail."' 
					where CPT_pseudo = '".$info->CPT_pseudo."';");
				}

				if ( $mdp1 != "changed")
				{ 
					if ($mdp1 == $mdp2)
					{
						$salt = "LeSelDUsCieclePourAllongerleMoT_TestPas1see781";
						$password=hash('sha256', $salt.$mdp1);
						$this->db->query("Update COMPTE set CPT_mot_de_passe = '".$password."'
						where CPT_pseudo = '".$info->CPT_pseudo."';");
					}
					else
					{
					 	echo "Confirmation du mot de passe erronée, Veuillez réessayer";
					}
				}				
			
				$data['info']=$this->db_model->get_profil($_SESSION['username']);
				$this->load->view('templates/haut'."_".$statut->CPT_statut);
				$this->load->view('profile_modification',$data);
				$this->load->view('templates/bas');
			}
		
	}





}

?>
