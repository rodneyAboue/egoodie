   <div class="content">
    <div class="contact">
      <div class="container">
          
        <div class="contact_top">
          <div class="col-md-8 contact_left">
 
<h1><?php echo "Liste des ". $titre; ?></h1>
<br/>


	
<div class="container">         
  <table class="table">
    <thead>
      <tr>
    <th>Pseudo</th>
	<th>Nom</th>
	<th>Prenom</th>
	<th>statut</th>
      </tr>
    </thead>
<?php
foreach($logins as $pseudo)
	{
	echo "<tbody>";
	echo "<tr>";
	echo "<th><h5>".$pseudo["CPT_pseudo"]."</h5></th>";
	echo "<th><h5>".$pseudo["PFL_nom"]."</h5></th>";
	echo "<th><h5>".$pseudo["PFL_prenom"]."</h5></th>";
	echo "<th><h5>".$pseudo["CPT_statut"]."</h5></th>";
	echo "</tr>";
	echo "</tbody";
	echo "</tr>";

	}
?>

  </table>
</div>
<a  href="<?php echo base_url();?>index.php/compte/creer/" class="btn" role="button">Ajouter un compte</a>
<!--
<?php
foreach($logins as $pseudo)
	{
	echo "<br/>";
	echo " -- ";
	echo $pseudo["CPT_pseudo"];
	echo " -- ";
	echo "<br/>";
	}
?>
-->

        </div>
      </div>
    </div>
  </div>
  </div>  
