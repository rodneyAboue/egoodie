	 <div class="content">
 		<div class="contact">
 			<div class="container">
		 			
				<div class="contact_top">
			 		<div class="col-md-8 contact_left">
<center>
<h1><?php echo $titre;?></h1>
<br/>
<div class="container">

  <table class="table">
    <thead>
      <tr>
        <th>Numero</th>
		<th>Titre</th>
        <th>Contenu</th>
        <th>Pseudo</th>
      </tr>
    </thead>
<?php
	foreach($actualites as $actu)
	{
		echo "<tbody>";
		echo "<tr>";
		echo "<th><h5>",$actu["ACT_id"],"</h5></th>";
		echo "<th><h5>",$actu["ACT_titre"],"</h5></th>";
		echo "<th><h5>",$actu["ACT_contenu"],"</h5></th>";
		echo "<th><h5>",$actu["CPT_pseudo"],"</h5></th>";
		echo "</tr>";
		echo "</tbody";
		echo "</tr>";
	}
?>
  </table>
</div>	
</center>

				 </div>
			</div>
		</div>
	</div>
	</div>	