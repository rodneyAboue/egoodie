<?php

if (!isset($_SESSION))
	{
	echo "Vous n'etes pas connecte";
	
	}

if (validation_errors())
		{
		 echo "Veuillez remplir le formulaire s’affiche ";
		}	
?>
</br>


   <div class="content">
    <div class="contact">
      <div class="container">
          
        <div class="contact_top">
          <div class="col-md-8 contact_left">
 
  <?php echo form_open('profile/modification'); ?>
   <p>Modificationdu profil</p>
    <div class="form_details">
    <input type="text" name="nom" placeholder="nom" required="required" />
    <input type="text" name="prenom" placeholder="prenom" required="required" />
    <input type="text" name="mail" placeholder="E-mail" />
    <input type="text" name="mdp1" placeholder="nouveau mot de passe" />
    <input type="text" name="mdp2" placeholder="confirmer nouveau mot de passe" />
                
      <div class="clearfix"> </div>
    
    <input type="submit" name="submit" value="Modifier" />
    <div class="sub-button">
    </div>
  </div>
</form>
         </div>
      </div>
    </div>
  </div>
  </div>  