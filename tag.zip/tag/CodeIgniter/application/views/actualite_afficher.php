
<h1><?php echo $titre;?></h1>
<br />
<!--
<?php 
	echo $actu->ACT_id; 
	echo(" -- ");
	echo $actu->ACT_contenue;
?>
-->



<div class="container">

  <table class="table">
    <thead>
      <tr>
        <th>Numero</th>
	<th>Titre</th>
        <th>Contenue</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?= $actu->ACT_id ?></td>
	<td><?= $actu->ACT_titre ?></td>
        <td><?= $actu->ACT_contenue ?></td>
      </tr>
    </tbody>
  </table>
</div>

