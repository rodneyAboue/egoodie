			<div class="footer-section">
				<div class="container">
					<div class="footer-top">
						<p>&copy; 2019 E.Goodies . All rights reserved | <a href="http://w3layouts.com">Acceuil</a></p>
					</div>
				</div>
			</div>
</body>
</html>
