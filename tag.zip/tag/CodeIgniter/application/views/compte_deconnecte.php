<h2> Vous etes deconnecte </h2>
<a href="http://localhost/gabarit/CodeIgniter/index.php/accueil/actualite/" type="button" class="btn btn-success" >Accueil</a>


<?php

if (isset($_SESSION['username']))
{
$pseudo = $_SESSION['username'];
echo $pseudo;
}
else
{
echo "deconnecte";
}
?>
