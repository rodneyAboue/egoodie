
<h2>Vous n'avez pas l'autaurisation d'acceder à cette page</h2>

<a href="http://localhost/gabarit/CodeIgniter/index.php/accueil/actualite">Accueil</a>
