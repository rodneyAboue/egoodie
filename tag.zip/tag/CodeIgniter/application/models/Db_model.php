<?php
class Db_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_all_compte()
	{
		$sql = $this->db->query("select CPT_pseudo, PFL_nom, PFL_prenom, PFL_mail,CPT_statut FROM COMPTE JOIN PROFIL using (CPT_pseudo);");
		return $sql->result_array();
	}

	
	public function get_an_actualite($numero)
	{
		$sql = $this->db->query("SELECT ACT_id, ACT_titre, ACT_contenu from ACTUALITE where ACT_id = $numero;");
		return $sql->row();
	}
	

	public function get_all_actualite()
	{
		$sql = $this->db->query("SELECT ACT_id, ACT_titre, ACT_contenu,CPT_pseudo from ACTUALITE;");
		return $sql->result_array();
	}
	
/*
	public function get_maxId()
	{
		$max = $this->db->query("SELECT max(PFL_id) as maxId from PROFIL;");
		return $max->row();
	}

*/
	public function set_compte()
	{
		$nom=$this->input->post('nom');
		$prenom=$this->input->post('prenom');
		$email=$this->input->post('mail');
		$pseudo=$this->input->post('pseudo');
		$mdp=$this->input->post('mdp');
		$statut=$this->input->post('statut');
		$pdr=$this->input->post('pdr');
		$salt = "LeSelDUsCieclePourAllongerleMoT_TestPas1see781";
		if (!empty ($pdr))
			{
			$req_compte="INSERT INTO COMPTE VALUES ('".addslashes($pseudo)."','".$salt.addslashes($mdp)."','".$statut."',".$pdr.");";
			$query_compte = $this->db->query($req_compte);
			}
		else
			{
			$req_compte="INSERT INTO COMPTE VALUES ('".addslashes($pseudo)."','".$salt.addslashes($mdp)."','".$statut."',null);";
			$query_compte = $this->db->query($req_compte);
			}

			$req_profil="INSERT INTO PROFIL VALUES ('".addslashes($nom)."','".addslashes($prenom)."','".addslashes($email)."','".addslashes($pseudo)."');";			
			$query_profil = $this->db->query($req_profil);

		return 1;

	}


	public function show_order_ids()
	{
		$cmd=$this->input->post('commande');
		$id=$this->input->post('identification');
		$show=$this->db->query("SELECT * FROM COMMANDE where CMD_identification= '".$id."' and CMD_commande = '".$cmd."';");

		return $show->row();
	}


	public function show_order()
	{
		$cmd=$this->input->post('commande');
		$id=$this->input->post('identification');
		$show=$this->db->query("SELECT * FROM COMMANDE left outer join tj_goodie_commande using (CMD_id) left outer join goodie using (GOO_id) 
		where CMD_identification= '".$id."' and CMD_commande = '".$cmd."';");

		return $show->result_array();
	}


	public function try_connect($username, $password)
	{ 
     	$query = $this->db->query("select * from compte where CPT_pseudo='".$username."' and CPT_mot_de_passe='".$password."'");
  		if($query->num_rows() > 0)  
        {  
			return true; 
        }  
        else  
        {  
			return false;
        }  
	}

	
	public function get_statuts($username)
	{
		$status=$this->db->query("Select CPT_statut from COMPTE where CPT_pseudo = '".$username."';");
		return $status->row();
	}


	public function get_profil($username)
	{
		$info=$this->db->query("SELECT * from COMPTE join PROFIL using(CPT_pseudo) where CPT_pseudo = '".$username."';");

		return $info->row();
	}

	public function update_profile_name($nom,$prenom,$mail)
	{
		$profil = $this->db_model->get_profil($_SESSION['username']);
		$this->db->query("Update PROFIL set PFL_prenom = '".$prenom."', PFL_nom = '".$nom."', PFL_mail = '".$mail."' 
					where PFL_id = '".$profil->PFL_id."';");
		return 1;
	}





}
?>
